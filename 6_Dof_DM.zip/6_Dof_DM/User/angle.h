#ifndef __ANGLE_H__
#define __ANGLE_H__

#include "main.h"

extern double xita1,xita2,xita3,xita4,xita5,xita6;

uint8_t angle(float X, float Y,float Z);


#endif