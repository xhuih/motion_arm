#include "angle.h"
double a,pi=3.14;
double X4,Y4,Z4,X5,Y5,Z5;
	double D4,D5,D54,R4;
	double J3_cos,J2R_cos;
double xita1,xita2,xita3,xita4,xita5,xita6;


uint8_t angle(float X, float Y,float Z)
{
	

	double L1,L2,L3,L4;
	a = (180.00/pi);
	L1 = 120;
	L2 = 120;
	L3 = 120;
	L4 = 120;

	xita1 = atan2(Y,X)*a;
	xita1 = xita1 - 90;

	//????????????5??
	X5 = X + (L4*sin(xita1/a));
	Y5 = Y - (L4*cos(xita1/a));
	Z5 = Z;


//**************************xita3*******************
	//D54???5???4??????,????15
	D54 = L3 * cos(15/a);
	X4 = X5 + (D54*sin(xita1/a));
	Y4 = Y5 - (D54*cos(xita1/a));
	Z4 = Z5 + L3*sin(15/a);
	//??J4????????
	//D4:J4?J2??
	D4 = sqrt((X4*X4)+(Y4*Y4)+(Z4*Z4));
	
	J3_cos = ((D4*D4) - (L2*L2) - (L1*L1))/(-2*L2*L1);
	if(J3_cos>1||J3_cos<-1) return 3;
	xita3 = acos(J3_cos)*a;
	xita3 =  xita3 -180;


//************xita4*********************
	//D5:J5?J2??,D4:J4?J2??
	D5 = sqrt((X5*X5)+(Y5*Y5)+(Z5*Z5));
	// J4L_cos = ((D5*D5) - (D4*D4) - (L3*L3))/(-2*D4*L3);
	// J4R_cos = ((L1*L1) - (D4*D4) - (L2*L2))/(-2*D4*L2);
	// xita4 = (acos(J4L_cos)+acos(J4R_cos))*a;
	// xita4 = 180 - xita4 ;

	//  xita4 = 15+xita3-xita2+90;
	xita4 = -(-105.0 + xita2 - xita3);

//****************xita2*****************
	

	//J4(X4,Y4)?T(X,Y)??????????????,???????
	//??Y4/X4 = Y/X => Y4*X = Y*X4
	R4 = (X4 * X + Y4 * Y) / (sqrt(X*X + Y*Y));
	J2R_cos = (L1*L1 + D4*D4 - L2*L2) / (2.0*L1*D4);
	if(J2R_cos>1||J2R_cos<-1) return 2;
	xita2 = 90 - (atan2(Z4, R4)*a) - (acos(J2R_cos) * a) ;



	//??
	// xita5 = 90 - xita2 - xita3 - xita4;

	// xita5 = 180 - xita2 - xita3 - xita4;
	//???????,????
	// xita5 = -90.00 - (-xita2) - (xita3) - (-xita4);
	xita5 = -90.00 + (xita2) + (-xita3) + (xita4);
	
	return 0;
}