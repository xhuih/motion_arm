/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fdcan.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "bsp_fdcan.h"
#include "dm_motor_ctrl.h"

#include "angle.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

double X,Y,Z;
uint8_t result;
extern double xita1,xita2,xita3,xita4,xita5,xita6;
double PI = (3.14/180);
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */
	if (htim->Instance == TIM3) {
		//dm_motor_ctrl_send(&hfdcan1, &motor[Motor1]);
		pos_ctrl(&hfdcan1,motor[Motor1].id, xita1*PI, 0.5);
		pos_ctrl(&hfdcan1,motor[Motor2].id, xita2*PI, 0.5);
		pos_ctrl(&hfdcan1,motor[Motor3].id, xita3*PI, 0.5);
		pos_ctrl(&hfdcan1,motor[Motor4].id, xita4*PI, 0.5);
		pos_ctrl(&hfdcan1,motor[Motor5].id, xita5*PI, 0.5);
		pos_ctrl(&hfdcan1,motor[Motor6].id, xita6*PI, 0.5);
		//pos_ctrl(&hfdcan1,Motor3, 1.2, 0.5);
		//pos_ctrl(&hfdcan1,Motor1, 6.28, 2);
//		read_all_motor_data(&motor[Motor1]);
//		
//		if(motor[Motor1].tmp.read_flag == 0)
//			dm_motor_ctrl_send(&hfdcan1, &motor[Motor1]);
		
	}
}

//dm_motor_ctrl������
void fdcan1_rx_callback(void)
{
    uint16_t rec_id;
    uint8_t rx_data[8] = {0};
    fdcanx_receive(&hfdcan1, &rec_id, rx_data);
    switch (rec_id)
    {
//        case 0x00: dm_motor_fbdata(&motor[Motor1], rx_data); receive_motor_data(&motor[Motor1], rx_data); break;
				case 0x11: dm_motor_fbdata(&motor[Motor1], rx_data); receive_motor_data(&motor[Motor1], rx_data); break;
				case 0x12: dm_motor_fbdata(&motor[Motor2], rx_data); receive_motor_data(&motor[Motor2], rx_data); break;
				case 0x13: dm_motor_fbdata(&motor[Motor3], rx_data); receive_motor_data(&motor[Motor3], rx_data); break;
				case 0x14: dm_motor_fbdata(&motor[Motor4], rx_data); receive_motor_data(&motor[Motor4], rx_data); break;
				case 0x15: dm_motor_fbdata(&motor[Motor5], rx_data); receive_motor_data(&motor[Motor5], rx_data); break;
				case 0x16: dm_motor_fbdata(&motor[Motor6], rx_data); receive_motor_data(&motor[Motor6], rx_data); break;
    }
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_FDCAN1_Init();
  MX_TIM3_Init();
  MX_USART1_UART_Init();
  MX_TIM4_Init();
  /* USER CODE BEGIN 2 */
	power(1);
	HAL_Delay(1000);
	
	bsp_fdcan_set_baud(&hfdcan1, CAN_CLASS, CAN_BR_1M);

	bsp_can_init();
	dm_motor_init();
	//motor[Motor1].ctrl.mode 	= pos_mode;******
	HAL_Delay(100);
	for(int i=0;i<10;i++)
	{
		enable_motor_mode(&hfdcan1,  motor[Motor1].id, pos_mode);
		enable_motor_mode(&hfdcan1,  motor[Motor2].id, pos_mode);
		enable_motor_mode(&hfdcan1,  motor[Motor3].id, pos_mode);
		enable_motor_mode(&hfdcan1,  motor[Motor4].id, pos_mode);
		enable_motor_mode(&hfdcan1,  motor[Motor5].id, pos_mode);
		enable_motor_mode(&hfdcan1,  motor[Motor6].id, pos_mode);
		HAL_Delay(50);
	}
	
	
//	write_motor_data(motor[Motor1].id, 10, pos_mode, 0, 0, 0);//�޸�ģʽ****
	HAL_Delay(100);
//	write_motor_data(motor[Motor1].id, 35, CAN_BR_5M, 0, 0, 0);***
//	HAL_Delay(100);***
//	read_motor_data(motor[Motor1].id, RID_CAN_BR); ****
//	dm_motor_disable(&hfdcan1, &motor[Motor1]);****
//	HAL_Delay(100);*****
	for(int i=0;i<10;i++)
	{
		save_motor_data(motor[Motor1].id, 10);
		save_motor_data(motor[Motor2].id, 10);
		save_motor_data(motor[Motor3].id, 10);
		save_motor_data(motor[Motor4].id, 10);
		save_motor_data(motor[Motor5].id, 10);
		save_motor_data(motor[Motor6].id, 10);
		HAL_Delay(50);
	}
	HAL_Delay(100);
	for(int i=0;i<10;i++)
	{
		dm_motor_enable(&hfdcan1, &motor[Motor1]);
		dm_motor_enable(&hfdcan1, &motor[Motor2]);
		dm_motor_enable(&hfdcan1, &motor[Motor3]);
		dm_motor_enable(&hfdcan1, &motor[Motor4]);
		dm_motor_enable(&hfdcan1, &motor[Motor5]);
		dm_motor_enable(&hfdcan1, &motor[Motor6]);
		HAL_Delay(50);
	}
	HAL_Delay(1000);
	HAL_TIM_Base_Start_IT(&htim3);
//	read_all_motor_data(&motor[Motor1]);

//enable_motor_mode(&hfdcan1,  Motor1, pos_mode);******
//		pos_ctrl(&hfdcan1,Motor2, 1, 1);

		X = 0;
		Y = 220;
		Z = 220;

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		
    /* USER CODE END WHILE */
		
		
		
		result = angle(X,Y,Z);
		

    /* USER CODE BEGIN 3 */
		
		
		
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Supply configuration update enable
  */
  HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE0);

  while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 2;
  RCC_OscInitStruct.PLL.PLLN = 40;
  RCC_OscInitStruct.PLL.PLLP = 1;
  RCC_OscInitStruct.PLL.PLLQ = 6;
  RCC_OscInitStruct.PLL.PLLR = 2;
  RCC_OscInitStruct.PLL.PLLRGE = RCC_PLL1VCIRANGE_3;
  RCC_OscInitStruct.PLL.PLLVCOSEL = RCC_PLL1VCOWIDE;
  RCC_OscInitStruct.PLL.PLLFRACN = 0;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_D3PCLK1|RCC_CLOCKTYPE_D1PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV2;
  RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
